-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- โฮสต์: localhost
-- เวลาในการสร้าง: 
-- รุ่นของเซิร์ฟเวอร์: 5.0.51
-- รุ่นของ PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- ฐานข้อมูล: `businessdb`
-- 

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `bank`
-- 

CREATE TABLE `bank` (
  `bank_id` double NOT NULL auto_increment,
  `bank_name` varchar(100) NOT NULL,
  `bank_account` varchar(20) NOT NULL,
  `bank_address` text NOT NULL,
  PRIMARY KEY  (`bank_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- dump ตาราง `bank`
-- 

INSERT INTO `bank` VALUES (1, 'ธนาคากรุงไทย  ', '311-111-1110', 'ฉะเชิงเทรา');
INSERT INTO `bank` VALUES (2, 'ธนาคารกรุงเทพ ', '411-111-1102', 'ฉะเชิงเทรา');
INSERT INTO `bank` VALUES (3, 'ธนาคารกสิกรไทย  ', '511-111-1231', 'ฉะเชิงเทรา');
INSERT INTO `bank` VALUES (4, 'ธนาคารทหารไทย', '611-111-1234', 'ฉะเชิงเทรา');
INSERT INTO `bank` VALUES (5, 'ธนาคารไทยพาณิชย์', '711-111-1234', 'ฉะเชิงเทรา');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `member`
-- 

CREATE TABLE `member` (
  `mem_id` int(7) NOT NULL auto_increment,
  `mem_nm` varchar(200) NOT NULL,
  `mem_email` varchar(200) NOT NULL,
  `mem_password` varchar(20) NOT NULL,
  `mem_tel` varchar(10) NOT NULL,
  `mem_address` text NOT NULL,
  `mem_status` varchar(10) NOT NULL default 'webuser',
  PRIMARY KEY  (`mem_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36 ;

-- 
-- dump ตาราง `member`
-- 

INSERT INTO `member` VALUES (5, 'asdfas', 'linkinneo@gmail.com', '123456', 'asdfa', 'asdfasdf', 'webuser');
INSERT INTO `member` VALUES (6, 'asdfas', 'dfas', 'asdfasd', 'asdfa', 'asdfasdf', 'webuser');
INSERT INTO `member` VALUES (7, 'asdfas', 'dfas', 'asdfasd', 'asdfa', 'asdfasdf', 'webuser');
INSERT INTO `member` VALUES (8, 'asdfas', 'dfas', 'asdfasd', 'asdfa', 'asdfasdf', 'webuser');
INSERT INTO `member` VALUES (9, 'asdfas', 'dfas', 'asdfasd', 'asdfa', 'asdfasdf', 'webuser');
INSERT INTO `member` VALUES (10, 'asdfa', 'asdf', 'asdf', 'asdf', 'asdf', 'webuser');
INSERT INTO `member` VALUES (11, 'fasdfas', 'dfasdf', 'asdfsadf', 'sadfasdf', 'asdfasdf', 'webuser');
INSERT INTO `member` VALUES (13, 'asdfasdf', 'asdfasd', 'sadfas', 'fasdfas', 'asdfasdf', 'webuser');
INSERT INTO `member` VALUES (14, 'asdfasdf', 'asdfasd', 'sadfas', 'fasdfas', 'asdfasdf', 'webuser');
INSERT INTO `member` VALUES (15, 'asdfasdf', 'asdfasd', 'sadfas', 'fasdfas', 'asdfasdf', 'webuser');
INSERT INTO `member` VALUES (16, 'fasdfas', 'fasdf', 'asdfasdfas', 'dfasdf', 'asdfasdf', 'webuser');
INSERT INTO `member` VALUES (17, 'fasdfas', 'fasdf', 'asdfasdfas', 'dfasdf', 'asdfasdf', 'webuser');
INSERT INTO `member` VALUES (18, 'sdfg', 'sdfg', 'sdfg', 'sdfgsdf', 'gsdfg', 'webuser');
INSERT INTO `member` VALUES (19, 'sdfg', 'sdfg', 'sdfg', 'sdfgsdf', 'gsdfg', 'webuser');
INSERT INTO `member` VALUES (20, 'sdfg', 'sdfg', 'sdfg', 'sdfgsdf', 'gsdfg', 'webuser');
INSERT INTO `member` VALUES (21, 'sdfg', 'sdfg', 'sdfg', 'sdfgsdf', 'gsdfg', 'webuser');
INSERT INTO `member` VALUES (22, 'sdfg', 'sdfg', 'sdfg', 'sdfgsdf', 'gsdfg', 'webuser');
INSERT INTO `member` VALUES (23, 'sdfg', 'sdfg', 'sdfg', 'sdfgsdf', 'gsdfg', 'webuser');
INSERT INTO `member` VALUES (24, 'sdfg', 'sdfg', 'sdfg', 'sdfgsdf', 'gsdfg', 'webuser');
INSERT INTO `member` VALUES (25, 'asdfasdf', 'fasdfasd', 'fsadfas', 'dfasdf', 'asdfasdf', 'webuser');
INSERT INTO `member` VALUES (26, 'asdfasdf', 'fasdfasd', 'fsadfas', 'dfasdf', 'asdfasdf', 'webuser');
INSERT INTO `member` VALUES (27, 'asdfasdf', 'fasdfasd', 'fsadfas', 'dfasdf', 'asdfasdf', 'webuser');
INSERT INTO `member` VALUES (28, 'dfhdf', 'hdfgh', 'dhfgdf', 'ghdfgh', 'dfghdfgh', 'webuser');
INSERT INTO `member` VALUES (29, 'หกเ', 'หเหกดเ', 'เหดเหกด', 'เหกดเ', 'หหกดเหกดเ', 'webuser');
INSERT INTO `member` VALUES (30, 'ฟหกดหฟก', 'ดฟหกดฟ', 'หกดฟหกด', 'ฟหกดฟห', 'กดฟหกดฟหกด', 'webuser');
INSERT INTO `member` VALUES (31, 'ฟหกดหฟก', 'ดฟหกดฟ', 'หกดฟหกด', 'ฟหกดฟห', 'กดฟหกดฟหกด', 'webuser');
INSERT INTO `member` VALUES (32, 'ดเ้กด', 'เ้กด', 'เ้กดเ้ก', 'ดเ้กด', 'เ้กดเ้กดเ', 'webuser');
INSERT INTO `member` VALUES (33, 'ดเ้กด', 'เ้กด', 'เ้กดเ้ก', 'ดเ้กด', 'เ้กดเ้กดเ', 'webuser');
INSERT INTO `member` VALUES (34, 'asdfasdf', 'fasdfasd', 'fsadfas', 'ghdfgh', 'าฟืนา', 'webuser');
INSERT INTO `member` VALUES (35, 'ฟหกดฟหก', 'ดฟหกด', 'ฟหกดฟหก', 'ดฟหกด', 'ฟหดกฟหกด', 'webuser');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `order`
-- 

CREATE TABLE `order` (
  `order_id` varchar(10) NOT NULL,
  `order_user` varchar(200) NOT NULL,
  `order_date` datetime NOT NULL,
  `order_bank_id` smallint(3) default NULL,
  `order_addr_send` text,
  `order_send_pic` varchar(200) default NULL,
  `order_detail_return` text,
  `order_return_pic` varchar(200) default NULL,
  PRIMARY KEY  (`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `order`
-- 

INSERT INTO `order` VALUES ('1448507456', 'thegod12012540@gmail.com', '2015-11-26 10:11:35', 3, '154 ถ.มรุพงษ์', '1448510045_img.jpg', NULL, NULL);
INSERT INTO `order` VALUES ('1448507523', 'thegod12012540@gmail.com', '2015-11-26 10:12:21', 1, '10 ต.หน้องใหญ่', '1448509987_img.jpg', 'ส่งให้ทาง EMS ครับผม\r\nตามหมายเลขในสลิป', '1448511629_img.jpg');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `order_detail`
-- 

CREATE TABLE `order_detail` (
  `order_id` varchar(10) NOT NULL,
  `order_pro_id` int(7) NOT NULL,
  `order_unit` int(7) NOT NULL,
  `order_pro_price` double(7,2) NOT NULL,
  PRIMARY KEY  (`order_id`,`order_pro_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `order_detail`
-- 

INSERT INTO `order_detail` VALUES ('1448507456', 24, 12, 2999.00);
INSERT INTO `order_detail` VALUES ('1448507456', 25, 1, 500.00);
INSERT INTO `order_detail` VALUES ('1448507523', 23, 1, 2999.00);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `order_temp`
-- 

CREATE TABLE `order_temp` (
  `order_temp_id` varchar(10) NOT NULL,
  `order_pro_id` int(7) NOT NULL,
  `order_pro_unit` int(7) NOT NULL,
  `order_user` varchar(200) NOT NULL,
  PRIMARY KEY  (`order_temp_id`,`order_pro_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `order_temp`
-- 

INSERT INTO `order_temp` VALUES ('1448341049', 25, 3, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448341049', 24, 3, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448341049', 22, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448341049', 23, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448341049', 20, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448341049', 17, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448341049', 16, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448341049', 15, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448341049', 18, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448341049', 19, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448431911', 25, 10, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448431911', 24, 15, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448431911', 19, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448444502', 25, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448444502', 24, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448444502', 23, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448444502', 22, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448503201', 25, 12, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448503201', 24, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448503201', 22, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448503780', 9, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448503780', 19, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448503780', 25, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448506204', 25, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448506247', 25, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448506247', 24, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448507456', 25, 1, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448507456', 24, 12, 'thegod12012540@gmail.com');
INSERT INTO `order_temp` VALUES ('1448507523', 23, 1, 'thegod12012540@gmail.com');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `product`
-- 

CREATE TABLE `product` (
  `pro_id` int(7) NOT NULL auto_increment,
  `pro_nm` varchar(200) NOT NULL,
  `pro_detail` text NOT NULL,
  `pro_price` double(7,2) NOT NULL,
  `pro_unit` int(7) NOT NULL,
  `pro_pic` varchar(300) NOT NULL,
  `pro_type` int(7) NOT NULL,
  PRIMARY KEY  (`pro_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

-- 
-- dump ตาราง `product`
-- 

INSERT INTO `product` VALUES (1, 'CPU1', 'n the Insert tab the galleries include items that are designed to coordinate with the overall look of your document You can use these galleries to insert tables headers footers lists cover pages and other document building blocks', 5000.00, 30, 'img02.png', 1);
INSERT INTO `product` VALUES (2, 'CPU2', 'n the Insert tab the galleries include items that are designed to coordinate with the overall look of your document You can use these galleries to insert tables headers footers lists cover pages and other document building blocks', 200.00, 40, 'img02.png', 1);
INSERT INTO `product` VALUES (3, 'CPU3', 'n the Insert tab the galleries include items that are designed to coordinate with the overall look of your document You can use these galleries to insert tables headers footers lists cover pages and other document building blocks', 3000.00, 50, 'img02.png', 1);
INSERT INTO `product` VALUES (4, 'CPU4', 'n the Insert tab the galleries include items that are designed to coordinate with the overall look of your document You can use these galleries to insert tables headers footers lists cover pages and other document building blocks', 4000.00, 60, 'img02.png', 1);
INSERT INTO `product` VALUES (5, 'CPU5', 'n the Insert tab the galleries include items that are designed to coordinate with the overall look of your document You can use these galleries to insert tables headers footers lists cover pages and other document building blocks', 6000.00, 70, 'img02.png', 2);
INSERT INTO `product` VALUES (6, 'CPU6', 'n the Insert tab the galleries include items that are designed to coordinate with the overall look of your document You can use these galleries to insert tables headers footers lists cover pages and other document building blocks', 8000.00, 80, 'img02.png', 2);
INSERT INTO `product` VALUES (7, 'CPU7', 'n the Insert tab the galleries include items that are designed to coordinate with the overall look of your document You can use these galleries to insert tables headers footers lists cover pages and other document building blocks', 10000.00, 90, 'img02.png', 2);
INSERT INTO `product` VALUES (8, 'CPU8', 'n the Insert tab the galleries include items that are designed to coordinate with the overall look of your document You can use these galleries to insert tables headers footers lists cover pages and other document building blocks', 12000.00, 100, 'img02.png', 2);
INSERT INTO `product` VALUES (9, 'CPU9', 'n the Insert tab the galleries include items that are designed to coordinate with the overall look of your document You can use these galleries to insert tables headers footers lists cover pages and other document building blocks', 14000.00, 110, 'img02.png', 3);
INSERT INTO `product` VALUES (10, 'CPU10', 'n the Insert tab the galleries include items that are designed to coordinate with the overall look of your document You can use these galleries to insert tables headers footers lists cover pages and other document building blocks', 16000.00, 120, 'img02.png', 3);
INSERT INTO `product` VALUES (11, 'CPU11', 'n the Insert tab the galleries include items that are designed to coordinate with the overall look of your document You can use these galleries to insert tables headers footers lists cover pages and other document building blocks', 18000.00, 130, 'img02.png', 3);
INSERT INTO `product` VALUES (12, 'CPU12', 'n the Insert tab the galleries include items that are designed to coordinate with the overall look of your document You can use these galleries to insert tables headers footers lists cover pages and other document building blocks', 20000.00, 140, 'img02.png', 3);
INSERT INTO `product` VALUES (13, 'CPU13', 'n the Insert tab the galleries include items that are designed to coordinate with the overall look of your document You can use these galleries to insert tables headers footers lists cover pages and other document building blocks', 22000.00, 150, 'img02.png', 4);
INSERT INTO `product` VALUES (14, 'CPU14', 'n the Insert tab the galleries include items that are designed to coordinate with the overall look of your document You can use these galleries to insert tables headers footers lists cover pages and other document building blocks', 24000.00, 160, 'img02.png', 4);
INSERT INTO `product` VALUES (15, 'CPU15', 'n the Insert tab the galleries include items that are designed to coordinate with the overall look of your document You can use these galleries to insert tables headers footers lists cover pages and other document building blocks', 26000.00, 170, 'img02.png', 4);
INSERT INTO `product` VALUES (16, 'CPU16', 'n the Insert tab the galleries include items that are designed to coordinate with the overall look of your document You can use these galleries to insert tables headers footers lists cover pages and other document building blocks', 28000.00, 180, 'img02.png', 4);
INSERT INTO `product` VALUES (17, 'CPU17', 'n the Insert tab the galleries include items that are designed to coordinate with the overall look of your document You can use these galleries to insert tables headers footers lists cover pages and other document building blocks', 30000.00, 190, 'img02.png', 4);
INSERT INTO `product` VALUES (18, 'CPU18', 'n the Insert tab the galleries include items that are designed to coordinate with the overall look of your document You can use these galleries to insert tables headers footers lists cover pages and other document building blocks', 32000.00, 200, 'img02.png', 4);
INSERT INTO `product` VALUES (19, 'CPU19', 'n the Insert tab the galleries include items that are designed to coordinate with the overall look of your document You can use these galleries to insert tables headers footers lists cover pages and other document building blocks', 34000.00, 210, 'img02.png', 5);
INSERT INTO `product` VALUES (20, 'CPU20', 'n the Insert tab the galleries include items that are designed to coordinate with the overall look of your document You can use these galleries to insert tables headers footers lists cover pages and other document building blocks', 36000.00, 220, 'img03.png', 5);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `product_type`
-- 

CREATE TABLE `product_type` (
  `protype_id` int(7) NOT NULL auto_increment,
  `protype_name` varchar(200) NOT NULL,
  PRIMARY KEY  (`protype_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- dump ตาราง `product_type`
-- 

INSERT INTO `product_type` VALUES (1, 'CPU');
INSERT INTO `product_type` VALUES (2, 'MainBoard');
INSERT INTO `product_type` VALUES (3, 'Power Supply');
INSERT INTO `product_type` VALUES (4, 'Ram');
INSERT INTO `product_type` VALUES (5, 'Hdd');
INSERT INTO `product_type` VALUES (6, 'Monitor');
